-- name: AddTodo :one 
INSERT INTO todos (id, name, description, created_at, updated_at, concluded, expires_at, priority, is_daily, history_since)
VALUES (
  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
)
RETURNING *;

-- name: GetTodos :many 
SELECT * FROM todos
ORDER BY expires_at; 

-- name: GetDailyTodos :many 
SELECT * FROM todos 
WHERE is_daily = true; 

-- name: GetTodoByName :one 
WITH ranked_todos AS (
  SELECT *,
    CASE
    -- same text 
    WHEN LOWER(name) = LOWER(?) THEN 1
    -- begins with the term 
    WHEN LOWER(name) LIKE LOWER(?) || '%' THEN 2
    WHEN LOWER(name) LIKE '%' || LOWER(?) || '%' THEN 3
    ELSE 4 
    END as relevance
  FROM todos
  WHERE LOWER(name) LIKE '%' || LOWER(?) || '%'
) 
SELECT * FROM ranked_todos
ORDER BY relevance, name COLLATE NOCASE
LIMIT 1;

-- name: GetIDByName :one 
SELECT id FROM todos 
WHERE name = ?;

-- name: UpdateTodoStatusByName :one 
UPDATE todos 
SET concluded = true, updated_at = datetime('now', 'localtime')
WHERE name LIKE ?
RETURNING *;

-- name: DeleteTodoByName :exec 
DELETE FROM todos 
WHERE name = ?;

-- name: DeleteConcluded :exec 
DELETE FROM todos 
WHERE concluded = true; 

-- name: CheckExpired :many 
SELECT * FROM todos 
WHERE expires_at < datetime('now') AND is_daily = false
ORDER BY expires_at DESC;

-- name: AutoCompleteDelete :one 
SELECT name FROM todos 
WHERE NAME LIKE ? || '%'
ORDER BY NAME LIMIT 5;
